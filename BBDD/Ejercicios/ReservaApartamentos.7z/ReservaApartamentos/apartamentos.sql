CREATE TABLE apartamentos_ID (
	id INT IDENTITY (1,1) NOT NULL
	, ubicacion VARCHAR NOT NULL
	, CONSTRAINT PK_apartamentos_apartamentosID PRIMARY KEY CLUSTERED (id)
);