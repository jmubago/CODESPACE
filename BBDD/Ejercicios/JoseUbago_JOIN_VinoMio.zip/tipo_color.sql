USE VinoMio;
GO
/*
What:	  Script for storing color type information tables
Why:		  For storing color type information
Who:		  jubago
Creation:	  6-Jan-2018
*/


-- Creating the table Denominacion
CREATE TABLE Tipo_Color (
    id TINYINT
    , nombre VARCHAR(10)
	);